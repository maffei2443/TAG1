Digite ,em ambiente Unix:
	make MAIN
	./main